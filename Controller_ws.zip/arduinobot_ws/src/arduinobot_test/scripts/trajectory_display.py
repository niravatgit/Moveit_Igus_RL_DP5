#!/usr/bin/env python3
import rospy
from std_msgs.msg import  Float32MultiArray

x=0
y=(0, 0, 0, 0)
abc=[]

def callback(data):
    # This function is called each time a new message is published on the topic /chatter
    # The message that has been published is then passed as input to this function
    global x
    global y
    #rospy.loginfo(data.data)

    if y != data.data:
        abc.append(data.data)
        print(abc)
        rospy.loginfo(x)
        x=x+1
        y= data.data
    #rospy.loginfo(x)

if __name__ == '__main__':
    # Inizialize a ROS node called listener
    rospy.init_node('listener', anonymous=True)

    # register a subscriber on the topic /chatter that will listen for String messages
    # when a new message is received, the callback function is triggered and starts its execution
    rospy.Subscriber("arduino/arm_actuate", Float32MultiArray, callback)

    # keeps the node up and running
    rospy.spin()