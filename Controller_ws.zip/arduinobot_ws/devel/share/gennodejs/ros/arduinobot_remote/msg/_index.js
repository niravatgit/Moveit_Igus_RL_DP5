
"use strict";

let ArduinobotTaskFeedback = require('./ArduinobotTaskFeedback.js');
let ArduinobotTaskAction = require('./ArduinobotTaskAction.js');
let ArduinobotTaskActionFeedback = require('./ArduinobotTaskActionFeedback.js');
let ArduinobotTaskActionGoal = require('./ArduinobotTaskActionGoal.js');
let ArduinobotTaskResult = require('./ArduinobotTaskResult.js');
let ArduinobotTaskGoal = require('./ArduinobotTaskGoal.js');
let ArduinobotTaskActionResult = require('./ArduinobotTaskActionResult.js');

module.exports = {
  ArduinobotTaskFeedback: ArduinobotTaskFeedback,
  ArduinobotTaskAction: ArduinobotTaskAction,
  ArduinobotTaskActionFeedback: ArduinobotTaskActionFeedback,
  ArduinobotTaskActionGoal: ArduinobotTaskActionGoal,
  ArduinobotTaskResult: ArduinobotTaskResult,
  ArduinobotTaskGoal: ArduinobotTaskGoal,
  ArduinobotTaskActionResult: ArduinobotTaskActionResult,
};
