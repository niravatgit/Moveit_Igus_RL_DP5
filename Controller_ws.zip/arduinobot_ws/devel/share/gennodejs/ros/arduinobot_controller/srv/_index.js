
"use strict";

let AnglesConverter = require('./AnglesConverter.js')

module.exports = {
  AnglesConverter: AnglesConverter,
};
