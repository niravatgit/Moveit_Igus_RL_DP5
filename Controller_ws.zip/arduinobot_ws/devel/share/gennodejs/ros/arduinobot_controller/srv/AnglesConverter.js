// Auto-generated. Do not edit!

// (in-package arduinobot_controller.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class AnglesConverterRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.base = null;
      this.shoulder = null;
      this.elbow = null;
      this.wrist = null;
      this.eef = null;
    }
    else {
      if (initObj.hasOwnProperty('base')) {
        this.base = initObj.base
      }
      else {
        this.base = 0.0;
      }
      if (initObj.hasOwnProperty('shoulder')) {
        this.shoulder = initObj.shoulder
      }
      else {
        this.shoulder = 0.0;
      }
      if (initObj.hasOwnProperty('elbow')) {
        this.elbow = initObj.elbow
      }
      else {
        this.elbow = 0.0;
      }
      if (initObj.hasOwnProperty('wrist')) {
        this.wrist = initObj.wrist
      }
      else {
        this.wrist = 0.0;
      }
      if (initObj.hasOwnProperty('eef')) {
        this.eef = initObj.eef
      }
      else {
        this.eef = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AnglesConverterRequest
    // Serialize message field [base]
    bufferOffset = _serializer.float64(obj.base, buffer, bufferOffset);
    // Serialize message field [shoulder]
    bufferOffset = _serializer.float64(obj.shoulder, buffer, bufferOffset);
    // Serialize message field [elbow]
    bufferOffset = _serializer.float64(obj.elbow, buffer, bufferOffset);
    // Serialize message field [wrist]
    bufferOffset = _serializer.float64(obj.wrist, buffer, bufferOffset);
    // Serialize message field [eef]
    bufferOffset = _serializer.float64(obj.eef, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AnglesConverterRequest
    let len;
    let data = new AnglesConverterRequest(null);
    // Deserialize message field [base]
    data.base = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [shoulder]
    data.shoulder = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [elbow]
    data.elbow = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [wrist]
    data.wrist = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [eef]
    data.eef = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 40;
  }

  static datatype() {
    // Returns string type for a service object
    return 'arduinobot_controller/AnglesConverterRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '041b90e40be979f56f7fa542477c80a6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 base
    float64 shoulder
    float64 elbow 
    float64 wrist
    float64 eef
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AnglesConverterRequest(null);
    if (msg.base !== undefined) {
      resolved.base = msg.base;
    }
    else {
      resolved.base = 0.0
    }

    if (msg.shoulder !== undefined) {
      resolved.shoulder = msg.shoulder;
    }
    else {
      resolved.shoulder = 0.0
    }

    if (msg.elbow !== undefined) {
      resolved.elbow = msg.elbow;
    }
    else {
      resolved.elbow = 0.0
    }

    if (msg.wrist !== undefined) {
      resolved.wrist = msg.wrist;
    }
    else {
      resolved.wrist = 0.0
    }

    if (msg.eef !== undefined) {
      resolved.eef = msg.eef;
    }
    else {
      resolved.eef = 0.0
    }

    return resolved;
    }
};

class AnglesConverterResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.base = null;
      this.shoulder = null;
      this.elbow = null;
      this.wrist = null;
      this.eef = null;
    }
    else {
      if (initObj.hasOwnProperty('base')) {
        this.base = initObj.base
      }
      else {
        this.base = 0.0;
      }
      if (initObj.hasOwnProperty('shoulder')) {
        this.shoulder = initObj.shoulder
      }
      else {
        this.shoulder = 0.0;
      }
      if (initObj.hasOwnProperty('elbow')) {
        this.elbow = initObj.elbow
      }
      else {
        this.elbow = 0.0;
      }
      if (initObj.hasOwnProperty('wrist')) {
        this.wrist = initObj.wrist
      }
      else {
        this.wrist = 0.0;
      }
      if (initObj.hasOwnProperty('eef')) {
        this.eef = initObj.eef
      }
      else {
        this.eef = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AnglesConverterResponse
    // Serialize message field [base]
    bufferOffset = _serializer.float64(obj.base, buffer, bufferOffset);
    // Serialize message field [shoulder]
    bufferOffset = _serializer.float64(obj.shoulder, buffer, bufferOffset);
    // Serialize message field [elbow]
    bufferOffset = _serializer.float64(obj.elbow, buffer, bufferOffset);
    // Serialize message field [wrist]
    bufferOffset = _serializer.float64(obj.wrist, buffer, bufferOffset);
    // Serialize message field [eef]
    bufferOffset = _serializer.float64(obj.eef, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AnglesConverterResponse
    let len;
    let data = new AnglesConverterResponse(null);
    // Deserialize message field [base]
    data.base = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [shoulder]
    data.shoulder = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [elbow]
    data.elbow = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [wrist]
    data.wrist = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [eef]
    data.eef = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 40;
  }

  static datatype() {
    // Returns string type for a service object
    return 'arduinobot_controller/AnglesConverterResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '041b90e40be979f56f7fa542477c80a6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 base
    float64 shoulder
    float64 elbow 
    float64 wrist
    float64 eef
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AnglesConverterResponse(null);
    if (msg.base !== undefined) {
      resolved.base = msg.base;
    }
    else {
      resolved.base = 0.0
    }

    if (msg.shoulder !== undefined) {
      resolved.shoulder = msg.shoulder;
    }
    else {
      resolved.shoulder = 0.0
    }

    if (msg.elbow !== undefined) {
      resolved.elbow = msg.elbow;
    }
    else {
      resolved.elbow = 0.0
    }

    if (msg.wrist !== undefined) {
      resolved.wrist = msg.wrist;
    }
    else {
      resolved.wrist = 0.0
    }

    if (msg.eef !== undefined) {
      resolved.eef = msg.eef;
    }
    else {
      resolved.eef = 0.0
    }

    return resolved;
    }
};

module.exports = {
  Request: AnglesConverterRequest,
  Response: AnglesConverterResponse,
  md5sum() { return 'd4984cdcf08443e74a796c5252f245ba'; },
  datatype() { return 'arduinobot_controller/AnglesConverter'; }
};
