var searchData=
[
  ['amplitude_691',['amplitude',['../a01021.html#a31bef58f966d97b1ace9bd3a58ffd9a6',1,'royale::IntermediatePoint']]],
  ['amplitudes_692',['amplitudes',['../a00965.html#a98bd082626ae3aae748ecace61f4c591',1,'royale::DepthData::amplitudes()'],['../a01025.html#a422434b5f092715ef5e821db377f0807',1,'royale::IntermediateData::amplitudes()']]]
];
