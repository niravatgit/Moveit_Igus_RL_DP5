var searchData=
[
  ['type_653',['type',['../a00993.html#aa470e5410b98509a9fe7e8da34a923cf',1,'royale::IEvent']]]
];
