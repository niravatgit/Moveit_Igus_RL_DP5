var searchData=
[
  ['hasdepthdata_578',['hasDepthData',['../a01009.html#ab75e1d296447034b18f1808739416428',1,'royale::IExtendedData']]],
  ['hasintermediatedata_579',['hasIntermediateData',['../a01009.html#a5f175cd74e954c3aa8db67049445e7e2',1,'royale::IExtendedData']]],
  ['hasirdata_580',['hasIrData',['../a01009.html#aa260d53d203f80facc38f74d2610cb32',1,'royale::IExtendedData']]]
];
