var searchData=
[
  ['modulationfrequencies_722',['modulationFrequencies',['../a01025.html#a8a090127b341725e9898ecf42321e182',1,'royale::IntermediateData::modulationFrequencies()'],['../a01065.html#a8a090127b341725e9898ecf42321e182',1,'royale::RawData::modulationFrequencies()']]],
  ['modulationscheme_723',['modulationScheme',['../a01065.html#ad22cc502baf6727c054412b45db0f871',1,'royale::RawData']]]
];
