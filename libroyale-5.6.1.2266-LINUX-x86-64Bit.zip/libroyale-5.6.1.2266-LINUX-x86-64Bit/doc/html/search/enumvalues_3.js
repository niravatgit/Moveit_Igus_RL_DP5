var searchData=
[
  ['data_5fnot_5ffound_778',['DATA_NOT_FOUND',['../a00139.html#a08d2011020d279958ab43e88aa954f83a113d2a552959871b7d7d5c29f9f2b774',1,'royale']]],
  ['deprecated1_779',['Deprecated1',['../a00139.html#aef5c3c8520a7846a338bd6143b1d8788a2a9aba6f325f6dfd5c5ec922d520e646',1,'royale']]],
  ['deprecated2_780',['Deprecated2',['../a00139.html#aef5c3c8520a7846a338bd6143b1d8788a97ce52f3676bb99da9a60c5ec49689af',1,'royale']]],
  ['deprecated3_781',['Deprecated3',['../a00139.html#aef5c3c8520a7846a338bd6143b1d8788a53238e5b8b0a84f37acc9b4de06eaf50',1,'royale']]],
  ['deprecated4_782',['Deprecated4',['../a00139.html#aef5c3c8520a7846a338bd6143b1d8788a05618e8afa79d61edcd2220dd2f1788d',1,'royale']]],
  ['depth_783',['Depth',['../a00139.html#ade70688fceca9ac2b41401bd8ed0119ca675056ad1441b6375b2c5abd48c27ef1',1,'royale']]],
  ['device_5falready_5finitialized_784',['DEVICE_ALREADY_INITIALIZED',['../a00139.html#a08d2011020d279958ab43e88aa954f83a95f1b5e72210ab9e32319f9f5130cd86',1,'royale']]],
  ['device_5fis_5fbusy_785',['DEVICE_IS_BUSY',['../a00139.html#a08d2011020d279958ab43e88aa954f83a28375078396aaa6663acd8f80cc286b4',1,'royale']]],
  ['device_5fnot_5finitialized_786',['DEVICE_NOT_INITIALIZED',['../a00139.html#a08d2011020d279958ab43e88aa954f83ac113642a58e4d7aa20c40d312372b82e',1,'royale']]],
  ['disconnected_787',['DISCONNECTED',['../a00139.html#a08d2011020d279958ab43e88aa954f83a99c8ce56e7ab246445d3b134724428f3',1,'royale']]],
  ['dutycycle_5fnot_5fsupported_788',['DUTYCYCLE_NOT_SUPPORTED',['../a00139.html#a08d2011020d279958ab43e88aa954f83a6389a464523be5f9e12507104e1fec6d',1,'royale']]]
];
