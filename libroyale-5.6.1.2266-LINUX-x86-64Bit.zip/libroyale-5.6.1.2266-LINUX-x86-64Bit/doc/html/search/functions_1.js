var searchData=
[
  ['depthdata_503',['DepthData',['../a00965.html#a4e7ed1d0b3c0b2dff0d9cbfb42a2f0e0',1,'royale::DepthData']]],
  ['depthimage_504',['DepthImage',['../a00969.html#acebfd53620d91fd14aed3a720478f897',1,'royale::DepthImage']]],
  ['depthirimage_505',['DepthIRImage',['../a00973.html#a6c5cad3b7f505bc61981e2bc7fa32c4b',1,'royale::DepthIRImage']]],
  ['describe_506',['describe',['../a00993.html#a27327afef4cf6a6c0b758d7fe925b426',1,'royale::IEvent']]]
];
