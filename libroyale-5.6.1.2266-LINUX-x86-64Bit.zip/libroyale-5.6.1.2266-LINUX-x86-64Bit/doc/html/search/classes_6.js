var searchData=
[
  ['variant_455',['Variant',['../a01069.html',1,'royale']]]
];
