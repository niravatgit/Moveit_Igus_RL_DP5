var searchData=
[
  ['data_695',['data',['../a00969.html#a5d286c9bcb0e4c4f62d09f5ec39118e4',1,'royale::DepthImage::data()'],['../a01053.html#abe222f6d3581e7920dcad5306cc906a8',1,'royale::IRImage::data()']]],
  ['depthconfidence_696',['depthConfidence',['../a00961.html#a79461a8e2b4f8f333f6a021b7c3f23d1',1,'royale::DepthPoint']]],
  ['distance_697',['distance',['../a01021.html#a06f14a9abd47b91465f895d5259cdc1b',1,'royale::IntermediatePoint']]],
  ['distances_698',['distances',['../a01025.html#aaa57b9b22bbdb46ea9b41b639cdc39e2',1,'royale::IntermediateData']]],
  ['distortionradial_699',['distortionRadial',['../a01057.html#ac2af38bcb5ff8cf46fa36ad9a934c220',1,'royale::LensParameters']]],
  ['distortiontangential_700',['distortionTangential',['../a01057.html#abbea34abfdd52f54068fde03c9d31ef2',1,'royale::LensParameters']]],
  ['dpdata_701',['dpData',['../a00973.html#a73a139442eec0d4fd9dd339e40e337d6',1,'royale::DepthIRImage']]]
];
