var searchData=
[
  ['width_397',['width',['../a00965.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthData::width()'],['../a00969.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthImage::width()'],['../a00973.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthIRImage::width()'],['../a01025.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::IntermediateData::width()'],['../a01053.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::IRImage::width()'],['../a01061.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::PointCloud::width()'],['../a01065.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::RawData::width()']]],
  ['writecalibrationtoflash_398',['writeCalibrationToFlash',['../a00977.html#a52efbc5a302011bf11de873ce2cb85c0',1,'royale::ICameraDevice']]],
  ['writedatatoflash_399',['writeDataToFlash',['../a00977.html#afc0c049fc3d981e99599c9d839ec33c7',1,'royale::ICameraDevice::writeDataToFlash(const royale::Vector&lt; uint8_t &gt; &amp;data)=0'],['../a00977.html#affc8cb147af86b80ee8d676fb9afc06e',1,'royale::ICameraDevice::writeDataToFlash(const royale::String &amp;filename)=0']]],
  ['writeregisters_400',['writeRegisters',['../a00977.html#a01a948b0b7a5bfe48a7635e1b3cfa2f7',1,'royale::ICameraDevice']]],
  ['wrong_5fdata_5fformat_5ffound_401',['WRONG_DATA_FORMAT_FOUND',['../a00139.html#a08d2011020d279958ab43e88aa954f83aacc2fff8761448264a43d967f18b0c06',1,'royale']]],
  ['ws_402',['WS',['../a00139.html#a0091e7176e35de5f55f6a2be3b236eafa54df3baef130c81e6ae8432a2567320a',1,'royale']]]
];
