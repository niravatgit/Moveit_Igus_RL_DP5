var searchData=
[
  ['width_733',['width',['../a00965.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthData::width()'],['../a00969.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthImage::width()'],['../a00973.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::DepthIRImage::width()'],['../a01025.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::IntermediateData::width()'],['../a01053.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::IRImage::width()'],['../a01061.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::PointCloud::width()'],['../a01065.html#ad0eab1042455a2067c812ab8071d5376',1,'royale::RawData::width()']]]
];
