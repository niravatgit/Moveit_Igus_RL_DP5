var searchData=
[
  ['rawdata_725',['rawData',['../a01065.html#adb5a1b16d97ae98ab38cd17334d1f862',1,'royale::RawData']]],
  ['rawframecount_726',['rawFrameCount',['../a01025.html#a1547f2f871c0fd55000faf697af6bd0a',1,'royale::IntermediateData::rawFrameCount()'],['../a01065.html#a1547f2f871c0fd55000faf697af6bd0a',1,'royale::RawData::rawFrameCount()']]]
];
