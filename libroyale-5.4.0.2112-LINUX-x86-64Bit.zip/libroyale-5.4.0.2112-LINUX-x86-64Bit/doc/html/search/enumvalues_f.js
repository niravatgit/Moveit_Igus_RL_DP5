var searchData=
[
  ['unknown_854',['UNKNOWN',['../a00139.html#a08d2011020d279958ab43e88aa954f83a696b031073e74bf2cb98e5ef201d4aa3',1,'royale']]],
  ['usecase_5fnot_5fsupported_855',['USECASE_NOT_SUPPORTED',['../a00139.html#a08d2011020d279958ab43e88aa954f83a207103e7edcdff3d0bf5a3cf508e144d',1,'royale']]]
];
