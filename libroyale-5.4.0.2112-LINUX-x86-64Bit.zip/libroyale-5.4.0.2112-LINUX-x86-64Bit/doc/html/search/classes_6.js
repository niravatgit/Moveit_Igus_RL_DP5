var searchData=
[
  ['variant_453',['Variant',['../a01069.html',1,'royale']]]
];
