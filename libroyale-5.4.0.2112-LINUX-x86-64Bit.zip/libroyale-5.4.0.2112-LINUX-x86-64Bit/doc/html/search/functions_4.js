var searchData=
[
  ['hasdepthdata_575',['hasDepthData',['../a01009.html#ab75e1d296447034b18f1808739416428',1,'royale::IExtendedData']]],
  ['hasintermediatedata_576',['hasIntermediateData',['../a01009.html#a5f175cd74e954c3aa8db67049445e7e2',1,'royale::IExtendedData']]]
];
