var searchData=
[
  ['slave_848',['SLAVE',['../a00139.html#aa534ed76b07c3983382a53e00e53e94aa79e19bc2ac33d6c81272024561992f37',1,'royale']]],
  ['spectre_5fnot_5finitialized_849',['SPECTRE_NOT_INITIALIZED',['../a00139.html#a08d2011020d279958ab43e88aa954f83af5b11523579e950a919ce57067b26030',1,'royale']]],
  ['spot_850',['SPOT',['../a00139.html#a0091e7176e35de5f55f6a2be3b236eafa5bac85a0c611ddef64ab0dfb383056f4',1,'royale']]],
  ['spot1_851',['Spot1',['../a00139.html#aef5c3c8520a7846a338bd6143b1d8788a40ea86c73fb21bb556a28549cfc17ed4',1,'royale']]],
  ['success_852',['SUCCESS',['../a00139.html#a08d2011020d279958ab43e88aa954f83ad0749aaba8b833466dfcbb0428e4f89c',1,'royale']]]
];
