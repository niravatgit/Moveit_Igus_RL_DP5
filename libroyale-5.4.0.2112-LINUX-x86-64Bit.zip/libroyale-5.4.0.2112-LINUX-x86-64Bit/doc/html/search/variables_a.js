var searchData=
[
  ['noise_720',['noise',['../a00961.html#abfc275fb52656acdce57b5d04e251e2d',1,'royale::DepthPoint::noise()'],['../a01025.html#a546aedd7ef96c313a5962f2483e82594',1,'royale::IntermediateData::noise()']]],
  ['numfrequencies_721',['numFrequencies',['../a01025.html#a51fa220d98aa8b5066650d19f922ad2a',1,'royale::IntermediateData']]]
];
