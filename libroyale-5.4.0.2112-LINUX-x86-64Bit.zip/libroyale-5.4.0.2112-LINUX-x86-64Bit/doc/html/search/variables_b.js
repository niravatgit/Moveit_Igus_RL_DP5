var searchData=
[
  ['phaseangles_722',['phaseAngles',['../a01065.html#aeb98c4fda9979b7339569c75d24487d5',1,'royale::RawData']]],
  ['principalpoint_723',['principalPoint',['../a01057.html#a1b46ccad9bef6fdc32aa9eb4268b7556',1,'royale::LensParameters']]],
  ['processingparameters_724',['processingParameters',['../a01025.html#a568d4b8156c0ff0cf473f452eddf809a',1,'royale::IntermediateData']]]
];
