var searchData=
[
  ['onevent_587',['onEvent',['../a00997.html#aa8ca251cb2777e4bc2fe4515f812b0b6',1,'royale::IEventListener']]],
  ['onnewdata_588',['onNewData',['../a00981.html#aee2898e664f67e962e969739ea6b300b',1,'royale::IDepthDataListener::onNewData()'],['../a00985.html#ad0fe0bdc7924f6a0f9e87b1304b113c1',1,'royale::IDepthImageListener::onNewData()'],['../a00989.html#a85e9c5f40bb769102b1639404c78f02a',1,'royale::IDepthIRImageListener::onNewData()'],['../a01013.html#aa2f557a95380d05fa0a0ee6abf171630',1,'royale::IExtendedDataListener::onNewData()'],['../a01017.html#a56318ed332bcdd1942323e0eceda6af2',1,'royale::IIRImageListener::onNewData()'],['../a01033.html#a82bc13ed23cd5b6181873b12098fe272',1,'royale::IPointCloudListener::onNewData()'],['../a01037.html#ad8a351b7fdc06b60af64f6774956d182',1,'royale::IRawDataListener::onNewData()']]],
  ['onnewexposure_589',['onNewExposure',['../a01005.html#adcfa03726aefb67c37e9e41906b6b7b2',1,'royale::IExposureListener']]],
  ['onnewexposures_590',['onNewExposures',['../a01001.html#a010a9ee258f810b1f9ccd2836fee8b6e',1,'royale::IExposureGroupListener']]],
  ['onplaybackstopped_591',['onPlaybackStopped',['../a01029.html#a3ca0f144a02875852710aa788e7cf7a0',1,'royale::IPlaybackStopListener']]],
  ['onrecordingstopped_592',['onRecordingStopped',['../a01045.html#a3722aaac4b1ce8584ac561099e957eb6',1,'royale::IRecordStopListener']]],
  ['operator_20bool_593',['operator bool',['../a01041.html#aecd9240fe1fa34049e5998dd3dbc03c8',1,'royale::IRecord']]],
  ['operator_21_3d_594',['operator!=',['../a01069.html#ae901b85d9ab9ad883c1e8de41dd212ef',1,'royale::Variant']]],
  ['operator_3c_595',['operator&lt;',['../a01069.html#a19922fcd36f575d19731a286a1fa9e54',1,'royale::Variant']]],
  ['operator_3c_3c_596',['operator&lt;&lt;',['../a00139.html#a02da8df51210469fe33eb3f51d2b6611',1,'royale::operator&lt;&lt;(::std::ostream &amp;os, royale::CameraStatus status)'],['../a00139.html#a8d7bbf7cc1da4aedec70894c4a878241',1,'royale::operator&lt;&lt;(std::ostream &amp;stream, const Variant &amp;variant)']]],
  ['operator_3d_597',['operator=',['../a00965.html#ad22042cbc054a31da40edb7604899276',1,'royale::DepthData::operator=()'],['../a00969.html#ae1c3e65c180defa9e55a9ea24f5e2fa5',1,'royale::DepthImage::operator=()'],['../a00973.html#aeedb51d937ff488953b1c3dfb57b19d6',1,'royale::DepthIRImage::operator=()'],['../a01025.html#a6019b6f3d6a41abcead3179359deb8de',1,'royale::IntermediateData::operator=()'],['../a01053.html#a631ed6fc787619fbdedef7654ffaecea',1,'royale::IRImage::operator=()'],['../a01061.html#abd359b2ac0e38eeb1426502cb0400d82',1,'royale::PointCloud::operator=()']]],
  ['operator_3d_3d_598',['operator==',['../a01069.html#a4de4c475748369c7cf06b26578609971',1,'royale::Variant']]]
];
